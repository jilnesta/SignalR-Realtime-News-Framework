﻿using Microsoft.AspNet.SignalR;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Owin;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Security.Permissions;
[assembly: OwinStartup(typeof(SignalRChat.Startup))]
namespace SignalRChat
{
    public class Startup
    {
        public static Dictionary<string, List<string>> CategorytoUser = new Dictionary<string, List<string>>();

        public static int newscount=0;
        public void Configuration(IAppBuilder app)
        {
            //// Any connection or hub wire up and configuration should go here
            //app.MapSignalR();            
                        var sqlConnectionString = @"Server=localhost;Database=signalr;Integrated Security=True;";
            GlobalHost.DependencyResolver.UseSqlServer(sqlConnectionString);
            SqlClientPermission clientPermission = new SqlClientPermission(PermissionState.Unrestricted);

            clientPermission.Demand();


            //Start the SQL Dependency
            SqlDependency.Stop(sqlConnectionString);
            SqlDependency.Start(sqlConnectionString);
            SetUpNewsDependency();
            GetAllUsersfromDB();
            //this.Configuration(app);            
            // Branch the pipeline here for requests that start with "/signalr"
            app.Map("/signalr", map =>
            {
                // Setup the CORS middleware to run before SignalR.
                // By default this will allow all origins. You can 
                // configure the set of origins and/or http verbs by
                // providing a cors options with a different policy.
                map.UseCors(CorsOptions.AllowAll);
                var hubConfiguration = new HubConfiguration
                {
                    // You can enable JSONP by uncommenting line below.
                    // JSONP requests are insecure but some older browsers (and some
                    // versions of IE) require JSONP to work cross domain
                     EnableJSONP = true
                };
                // Run the SignalR pipeline. We're not using MapSignalR
                // since this branch already runs under the "/signalr"
                // path.

                map.RunSignalR(hubConfiguration);
            });
           
        }


        //Pulls data from Users_tbl for all the users and their subscription categories
        private void GetAllUsersfromDB()
        {
            var sqlConnectionString = @"Server=localhost;Database=signalr;Integrated Security=True;";
            GlobalHost.DependencyResolver.UseSqlServer(sqlConnectionString);

            string commandText = @" Select Username,Subscription from dbo.User_tbl;";


            using (SqlConnection connection = new SqlConnection(sqlConnectionString))
            {

                using (SqlCommand command = new SqlCommand(commandText, connection))
                {
                    connection.Open();
                    
                    // NOTE: You have to execute the command, or the notification will never fire.
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string c = reader.GetString(1);
                            if (!CategorytoUser.ContainsKey(reader.GetString(1)))
                            {
                                List<string> users = new List<string>();
                                CategorytoUser.Add(reader.GetString(1), users);
                            }

                            CategorytoUser[reader.GetString(1)].Add(reader.GetString(0));
                        }
                    }
                }
            }
        
        }

        private void sqlDependency_OnChange(object sender, SqlNotificationEventArgs e)
        {

            if (e.Info == SqlNotificationInfo.Insert)
            {
                SqlDependency dependency = sender as SqlDependency;

                //dependency.OnChange -= sqlDependency_OnChange;
                ReadLatestNews();
                SetUpNewsDependency();

            }
        }

        private void SetUpNewsDependency()
        {

            var sqlConnectionString = @"Server=localhost;Database=signalr;Integrated Security=True;";
            GlobalHost.DependencyResolver.UseSqlServer(sqlConnectionString);
            SqlClientPermission clientPermission = new SqlClientPermission(PermissionState.Unrestricted);

            clientPermission.Demand();


            //Start the SQL Dependency
            SqlDependency.Stop(sqlConnectionString);
            SqlDependency.Start(sqlConnectionString);

            string commandText = @" Select Category,News from dbo.News_tbl;";


            using (SqlConnection connection = new SqlConnection(sqlConnectionString))
            {

                using (SqlCommand command = new SqlCommand(commandText, connection))
                {
                    connection.Open();
                    var sqlDependency = new SqlDependency(command);

                    sqlDependency.OnChange += new OnChangeEventHandler(sqlDependency_OnChange);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        //while (reader.Read())
                        //{
                            //string category = reader.GetString(0);
                            //string message = reader.GetString(1);

                            //IHubContext context = GlobalHost.ConnectionManager.GetHubContext<ChatHub>();
                            //List<string> userslist = CategorytoUser[category];

                            //foreach (string groupname in userslist)
                            //{
                            //    context.Clients.Group(groupname).broadcastMessage(category, message);
                            //}

                        //}
                    }
                }
            }

        }

        private void ReadLatestNews()
        {
            var sqlConnectionString = @"Server=localhost;Database=signalr;Integrated Security=True;";
            GlobalHost.DependencyResolver.UseSqlServer(sqlConnectionString);

            string commandText = @" Select Category,News from dbo.News_tbl where NewsId>"+newscount+";";


            using (SqlConnection connection = new SqlConnection(sqlConnectionString))
            {

                using (SqlCommand command = new SqlCommand(commandText, connection))
                {
                    connection.Open();                   

                    // NOTE: You have to execute the command, or the notification will never fire.
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string category = reader.GetString(0);
                            string message = reader.GetString(1);

                            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<ChatHub>();
                            List<string> userslist = CategorytoUser[category];

                            foreach (string groupname in userslist)
                            {
                                context.Clients.Group(groupname).broadcastMessage(category, message);
                            }
                            newscount++;
                        }
                    }
                }
            }
        
        
        }


    }
}
