﻿using System;
using System.Web;
using Microsoft.AspNet.SignalR;
using System.Collections.Generic;
namespace SignalRChat
{
    
    public class ChatHub : Hub
    {

        //public List<string> CategoryA = new List<string>() { "vishalsinghdeepak@gmail.com", "abhishekgupta@gmail.com", "mohitagrawal@gmail.com" };
        //public List<string> CategoryB = new List<string>() { "vishalsinghdeepak@gmail.com", "mohitagrawal@gmail.com" };
        //public List<string> CategoryC = new List<string>() { "mohitagrawal@gmail.com" };
        
        public void CreateGroups(string email)
        {
            Groups.Add(Context.ConnectionId, email);
        }

        public void Send(string name, string message)
        {
            List<string> userslist=null;
            //if (name.Equals("CategoryA"))
            //    userslist = CategoryA;
            //if (name.Equals("CategoryB"))
            //    userslist = CategoryB;
            //if (name.Equals("CategoryC"))
            //    userslist = CategoryC;
            userslist = Startup.CategorytoUser[name];
            
            foreach(string groupname in userslist)
            {
                Clients.Group(groupname).broadcastMessage(name, message);
            }
            // Call the broadcastMessage method to update clients.
            //Clients.All.broadcastMessage(name, message);
        }
        public void Acknowledge(string category,string email,string comment, string date, string message)
        {
            Clients.All.showdetails(category,email, comment, date, message);
        }
        
    }
}